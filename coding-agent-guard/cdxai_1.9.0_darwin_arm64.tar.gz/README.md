# cloudanix-coding-agent-guard (Go)

> **Status:** GA — `v1.0.0` released 2026-06-14. The binary is **`cdxai`**
> (renamed from `cloudanix-guard`). v2 in progress: multi-axis control plane
> (per-tool action-authz, ingress/output detection) and broader agent support.
> Built to 1:1 parity with the Python implementation at v0.1.1 (see
> [`Cloudanix/cloudanix-coding-agent-guard`](https://github.com/Cloudanix/cloudanix-coding-agent-guard)).

On-device firewall for coding agents (Claude Code, OpenAI Codex CLI,
Kiro, Cursor, Windsurf). Inspects every prompt and every tool call for
secrets, PII, and sensitive files **before** anything leaves the
developer's machine. Decides **allow / redact / block** per a local policy
synced from the Cloudanix Console.

This Go rewrite preserves the same wire protocol, the same policy YAML
shape, the same NF-PRIV-1 privacy contract, and the same CLI surface as
the Python implementation. The binary is now **`cdxai`** (renamed from
`cloudanix-guard`); existing installs re-run `cdxai install` to re-wire
their agent hooks under the new name.

## Why Go (vs the Python at v0.1.1)

- **Single static binary, no Python runtime.** Customer install collapses
  to `curl -o cdxai …; chmod +x`. No venv, no `pip install`,
  no "Python 3.9+ on PATH" requirement.
- **Hook latency ~10 ms cold-start** vs 100–300 ms for Python. Hooks fire
  on every UserPromptSubmit and every PreToolUse (blocking egress scans),
  plus an audit-only PostToolUse pass that records secrets/PII in content
  the agent fetched (e.g. `curl … | head`) where there was no local file
  to pre-scan — this is on the agent user's interactive critical path.
- **Cross-platform signing/notarization** trivial (Apple, Microsoft).
- **goreleaser-based release pipeline** with multi-arch builds, archived
  in `Cloudanix/artifacts/coding-agent-guard/` (same channel as the
  Python wheel today).

See [`PORTING.md`](https://github.com/Cloudanix/cloudanix-coding-agent-guard/blob/main/PORTING.md)
in the existing Python repo (TBD) for the module-by-module porting plan
and parity-validation strategy.

## Quick start (dev)

```bash
make build           # produces ./cdxai
make test            # unit tests with race detector
make lint            # golangci-lint
make smoke           # end-to-end smoke against a fixture corpus (TBD)
./cdxai --version
```

## Project layout

```
cmd/cdxai/    binary entry point
internal/
  cli/                  argument parsing + subcommand dispatch
  config/               ~/.cdxai/config.yaml read/write
  policy/               6-mode enforcement engine
  enforce/              apply(payload, decision); NF-PRIV-1 scrub on block
  inspector/            secret / PII / file scanners (regex-only in v1)
  hook/                 stdin JSON → Payload normalisation
  install/              Claude/Kiro/Codex/Cursor/Windsurf hook wiring
                        (flat-hook agents share flat_hook.go)
  telemetry/            spool + flush + backoff
  sync/                 policy pull from console + heartbeat
  state/                pause / resume + audit log
  exceptions/           grant / revoke / find_active_for_rule
  directive/            cloudanix:allow parser
  inventory/            machine inventory: AI tooling, MCP, skills, packages
  buildinfo/            version + commit SHA (set via goreleaser ldflags)
```

## Machine inventory (`cdxai inventory`)

Beyond the egress firewall, the guard ships a privacy-first **inventory**
of the developer machine to the Console for fleet governance and
supply-chain correlation. It detects AI CLIs / desktop apps, IDEs and
their extensions, MCP servers (env-stripped), local model runtimes, agent
skills, and — with `--enable-packages` — installed packages.

Packages are read **directly from on-disk lockfiles and package-manager
metadata; the guard never executes a package manager** (`npm ls`,
`pip list`, …). That is faster, needs no tool on `PATH`, can't hang, and —
crucially — captures **project dependency graphs** (the real supply-chain
surface) that a global `npm ls -g` can't see. Each package record carries
`ecosystem` + `normalized_name` + `version` (for a direct JOIN against the
Console's CVE / threat-intel database), plus provenance (`source_file`,
`project_path`, `direct`) and a `has_lifecycle_scripts` risk flag — the
slopsquatting execution vector — that the Console can rank on before any
CVE match. Snapshots carry **no secrets** (see
[docs/inventory-sources.md](docs/inventory-sources.md)).

```bash
cdxai inventory --print                    # AI tooling + MCP + skills, no packages
cdxai inventory --print --enable-packages  # + on-disk package inventory
cdxai inventory --enable-packages          # scan + ship to the Console
```

## What changes vs Python v0.1.1

- **Presidio (NER-based PII detection) is dropped for v1.** Regex-based
  PII detection (the default) is preserved 1:1. NER will return as a
  separate workstream in v1.1+.
- Everything else is intended to be behaviourally identical.

## License

Proprietary. See [LICENSE](LICENSE).
